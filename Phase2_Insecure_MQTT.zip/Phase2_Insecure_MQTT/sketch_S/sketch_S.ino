#include <WiFi.h>
#include <PubSubClient.h>

const char* ssid = "Hajjaj2020";
const char* password = "tSk@2014";
const char* mqtt_server = "192.168.0.228";

WiFiClient espClient;
PubSubClient client(espClient);

const int buttonPin = 4;
bool lastState = HIGH;

void reconnect() {
  while (!client.connected()) {

    Serial.print("Connecting to MQTT...");

    String clientId = "ESP32Sender-";
    clientId += String((uint32_t)ESP.getEfuseMac(), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("Connected");
    } else {
      Serial.print("Failed, rc=");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

void setup() {

  Serial.begin(115200);

  pinMode(buttonPin, INPUT_PULLUP);

  Serial.println("Connecting to WiFi...");

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  client.setServer(mqtt_server, 1883);

  reconnect();
}

void loop() {

  if (!client.connected())
    reconnect();

  client.loop();

  bool currentState = digitalRead(buttonPin);

  if (currentState != lastState) {

    if (currentState == LOW) {
      client.publish("home/button", "ON");
      Serial.println("Button Pressed -> ON");
    } else {
      client.publish("home/button", "OFF");
      Serial.println("Button Released -> OFF");
    }

    lastState = currentState;

    delay(100);
  }
}