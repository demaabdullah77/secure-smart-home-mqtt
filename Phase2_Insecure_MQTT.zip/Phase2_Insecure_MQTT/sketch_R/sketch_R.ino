#include <WiFi.h>
#include <PubSubClient.h>

const char* ssid = "Hajjaj2020";
const char* password = "tSk@2014";
const char* mqtt_server = "192.168.0.228";

WiFiClient espClient;
PubSubClient client(espClient);

const int ledPin = 2;

void callback(char* topic, byte* payload, unsigned int length) {

  String message = "";

  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  Serial.print("Received: ");
  Serial.println(message);

  if (message == "ON") {
    digitalWrite(ledPin, HIGH);
  }
  else if (message == "OFF") {
    digitalWrite(ledPin, LOW);
  }
}

void reconnect() {

  while (!client.connected()) {

    Serial.print("Connecting to MQTT...");

    String clientId = "ESP32Receiver-";
    clientId += String((uint32_t)ESP.getEfuseMac(), HEX);

    if (client.connect(clientId.c_str())) {

      Serial.println("Connected");

      client.subscribe("home/button");

      Serial.println("Subscribed to home/button");

    } else {

      Serial.print("Failed, rc=");
      Serial.println(client.state());

      delay(2000);
    }
  }
}

void setup() {

  Serial.begin(115200);

  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, LOW);

  Serial.println("Connecting to WiFi...");

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);

  reconnect();
}

void loop() {

  if (!client.connected())
    reconnect();

  client.loop();
}